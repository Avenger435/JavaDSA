package core.arrays;

public class Array {

}
