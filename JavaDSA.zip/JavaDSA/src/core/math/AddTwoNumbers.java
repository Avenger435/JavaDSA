package core.math;

public class AddTwoNumbers {

	public static void main(String[] args) {

		System.out.println(addTwoNums(1, 2));

	}

	private static int addTwoNums(int a, int b) {
		while (b != 0) {
			int carry = (a & b) << 1;
			a = a ^ b;
			b = carry;
		}
		return a;
	}

}
