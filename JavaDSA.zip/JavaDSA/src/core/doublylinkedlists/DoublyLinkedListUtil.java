package core.doublylinkedlists;

public class DoublyLinkedListUtil {

    public static void main(String[] args) {

        int[] arr = {1, 2, 3, 4, 5};
        DoublyListNode doublyListNode = createDoublyListNode(arr);
        printDoublyListNode(doublyListNode);

    }

    static void printDoublyListNode(DoublyListNode head) {
        System.out.println("null -> ");
        while (head.next != null) {
            System.out.print(head.val + "-> ");
            head = head.next;
        }
        System.out.print("null");
    }

    static DoublyListNode createDoublyListNode(int[] arr) {
        if (arr == null || arr.length == 0) {
            return null;
        }

        DoublyListNode head = new DoublyListNode(arr[0]);
        //pointer to traverse the DLL
        DoublyListNode curr = head;
        //Iterate till the end.
        for (int i = 1; i < arr.length; i++) {
            //create a new node.
            DoublyListNode newNode = new DoublyListNode(arr[i]);
            //make new node to next of current node
            curr.next = newNode;
            //make prev of newNode previous to current node
            newNode.prev = curr;
            //move the current.
            curr = curr.next;
        }
        return head;
    }

    static void 

}

class DoublyListNode {
    int val;
    DoublyListNode next;
    DoublyListNode prev;

    DoublyListNode(int val) {
        this.val = val;
    }

    DoublyListNode(int val, DoublyListNode prev) {
        this.val = val;
        this.prev = prev;
    }

    DoublyListNode(int val, DoublyListNode prev, DoublyListNode next) {
        this.val = val;
        this.prev = prev;
        this.next = next;
    }

}