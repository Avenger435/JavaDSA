package core.linkedlists;

public class IntersectionTwoLL {

	public static void main(String[] args) {

		// 4,1,8,4,5
		ListNode headA = new ListNode(4);
		headA.next = new ListNode(1);
		headA.next.next = new ListNode(8);
		headA.next.next.next = new ListNode(4);
		headA.next.next.next.next = new ListNode(5);

		// 5,6,1,8,4,5
		ListNode headB = new ListNode(5);
		headB.next = new ListNode(6);
		headB.next.next = new ListNode(1);
		headB.next.next.next = new ListNode(8);
		headB.next.next.next.next = new ListNode(4, new ListNode(5));

		getIntersectionNode(headA, headB);

	}

	public static ListNode getIntersectionNode(ListNode headA, ListNode headB) {

		// p1 points to the head of HeadA and p2 to the head of HeadB
		ListNode p1 = headA;
		ListNode p2 = headB;

		while (p1 != p2) {
			// p1 takes a step , if it reaches the end of List A, switch to list B
			if (p1 == null) {
				p1 = headB;
			} else {
				p1 = p1.next;
			}

			// p2 takes a step , if it reaches the end of List B, switch to list A
			if (p2 == null) {
				p2 = headA;
			} else {
				p2 = p2.next;
			}
		}

		return p1;

	}

}
