package core.linkedlists;

public class MiddleNodeLL {

	public static void main(String[] args) {

		// 1,2,3,4,5
		ListNode head = new ListNode(1, new ListNode(2, new ListNode(3, new ListNode(4, new ListNode(5, null)))));

		System.out.println("headNode: " + head);
		System.out.println("result: " + middleNode(head));
	}

	public static ListNode middleNode(ListNode head) {

		if (head == null) {
			return head;
		}

		ListNode slow = head;
		ListNode fast = head;

		while (fast != null && fast.next != null) {
			fast = fast.next.next;
			slow = slow.next;
		}

		return slow;

	}

}
