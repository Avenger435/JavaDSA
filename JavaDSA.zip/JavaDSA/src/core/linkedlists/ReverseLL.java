package core.linkedlists;

public class ReverseLL {

	public static void main(String[] args) {

		ListNode l1 = new ListNode(1);
		l1.next = new ListNode(2);
		l1.next.next = new ListNode(3);
		l1.next.next.next = new ListNode(4);
		l1.next.next.next.next = new ListNode(5);
		System.out.println(l1);
		System.out.println(reverseLinkedList(l1));
	}

	public static ListNode reverseLinkedList(ListNode head) {

		if (head == null) {
			return head;
		}

		ListNode next = null;
		ListNode prev = null;
		ListNode curr = head;

		while (curr != null) {
			next = curr.next; // store next value.
			curr.next = prev; // move current value to prev
			prev = curr; //
			curr = next;
		}

		return prev;
	}

}
