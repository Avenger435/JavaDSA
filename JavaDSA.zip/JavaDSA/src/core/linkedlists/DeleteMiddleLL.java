package core.linkedlists;

public class DeleteMiddleLL {

	public static void main(String[] args) {

		ListNode l1 = new ListNode(1);
		l1.next = new ListNode(2);
		l1.next.next = new ListNode(3);
		l1.next.next.next = new ListNode(4);
		l1.next.next.next.next = new ListNode(5);
		System.out.println(l1);
		System.out.println(deleteMid(l1));

	}

	private static ListNode deleteMid(ListNode head) {

		ListNode fast = head;
		ListNode slow = head;
		ListNode prev = null;

		if (head == null) {
			return head;
		}

		while (fast != null && fast.next != null) {
			fast = fast.next.next;
			prev = slow;
			slow = slow.next;
		}

		if (prev != null) {
			prev.next = slow.next;
		}

		return head;
	}

}
