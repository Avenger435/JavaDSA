package core.linkedlists;

public class PartitionListLL {

	public static void main(String[] args) {

		// 1,4,3,2,5,2
		ListNode head = new ListNode(1,
				new ListNode(4, new ListNode(3, new ListNode(2, new ListNode(5, new ListNode(2, null))))));

//		2,0,1,2,4,4,4,1,0
		ListNode head2 = new ListNode(2, new ListNode(0, new ListNode(1, new ListNode(2,
				new ListNode(4, new ListNode(4, new ListNode(4, new ListNode(1, new ListNode(0, null)))))))));

		System.out.println("Head Node : " + head);
		System.out.println("Result Node: " + partition(head2, 1));
	}

	public static ListNode partition(ListNode head, int x) {

		// dummy head node for list containing nodes less than x;
		ListNode dummy1 = new ListNode(-1);
		// dummy head node for list containing nodes greather than x;
		ListNode dummy2 = new ListNode(-1);

		// we store results in these pointers,later we will join them
		ListNode p1 = dummy1;
		ListNode p2 = dummy2;

		// p is responsible for traversing across the original list,
		// similar to the logic of merging two sorted lists;
		// here we are spitting one list into two lists.
		ListNode p = head;

		while (p != null) {

			if (p.val >= x) {
				p2.next = p;
				p2 = p2.next;
			} else {
				p1.next = p;
				p1 = p1.next;
			}
			// we cannot move the p pointer directly
			// p=p.next;
			// disconnect the next pointer of each node in the original list;
			ListNode temp = p.next;
			p.next = null;
			p = temp;
		}

		// connect the lists
		p1.next = dummy2.next;
		return dummy1.next;
	}

}
