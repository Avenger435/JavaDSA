package core.linkedlists;

import java.util.Arrays;

public class MergeTwoSortedListsLL {

	public static void main(String[] args) {
		// 1,2,4
		ListNode headA = new ListNode(1, new ListNode(2, new ListNode(4, null)));

		// 1,3,4
		ListNode headB = new ListNode(1, new ListNode(3, new ListNode(4, null)));
		System.out.println(headA);
		System.out.println(headB);
		System.out.println("result: " + mergeTwoLists(headA, headB));

	}

	public static ListNode mergeTwoLists(ListNode headA, ListNode headB) {

		// virtual node.
		ListNode dummy = new ListNode(-1);
		ListNode result = dummy;
		ListNode p1 = headA;
		ListNode p2 = headB;

		while (p1 != null && p2 != null) {

			// compare pointers p1 and p2
			// attach the node with the smaller value to the pointer result.
			if (p1.val > p2.val) {
				result.next = p2;
				p2 = p2.next;
			} else {
				result.next = p1;
				p1 = p1.next;
			}
			// advance the result pointer.
			result = result.next;
		}

		if (p1 != null) {
			result.next = p1;
		}

		if (p2 != null) {
			result.next = p2;
		}

		return dummy.next;
	}

}
