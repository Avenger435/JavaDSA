package core.linkedlists;

public class CycleDetectionIILL {

	public static void main(String[] args) {

		ListNode head = new ListNode(3);
		head.next = new ListNode(2);
		head.next.next = new ListNode(0);
		head.next.next = new ListNode(-4, head.next);

		detectCycle(head);

	}

	private static ListNode detectCycle(ListNode head) {
		if (head == null) {
			return null;
		}
		
		//set two pointers, fast moves 2 points, slow moves 1 point at a time respectively
		ListNode fast = head;
		ListNode slow = head;
		while (fast != null && fast.next != null) {
			fast = fast.next.next;
			slow = slow.next;
			//if slow meets fast, we have a cycle.
			if (slow == fast)
				break;
		}

		if (fast == null || fast.next == null) {
			//fast encountering a null pointer means there is no cycle.
			return null;
		}

		//reassign the head node to slow.
		slow = head;
		//move fast and slow points simultaneously, 
		// the intersection point is the cycle's entry point.
		while (slow != fast) {
			fast = fast.next;
			slow = slow.next;
		}

		return slow;
	}

}
