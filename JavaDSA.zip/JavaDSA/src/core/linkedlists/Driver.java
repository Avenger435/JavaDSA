package core.linkedlists;

public class Driver {

	public static void main(String[] args) {

		ListNode l1 = new ListNode(1, new ListNode(2, new ListNode(3, new ListNode(4, new ListNode(5)))));
		System.out.println(l1);
//		System.out.println(reverseLinkedList(l1));

//		System.out.println(deleteMiddle(l1));

		System.out.println(oddEvenList(l1));

	}

	public static ListNode oddEvenList(ListNode head) {

		// first node is odd, next is even and so on.

		if (head == null || head.next == null) {
			return head;
		}
		ListNode prev = null;
		ListNode curr = head;
		ListNode next = null;
		while (curr != null) {
			next = curr.next; // store next node
			curr.next = prev; // reverse current node's pointer
			prev = next.next; // move pointers one pos ahead
			curr = prev;
		}
		return curr;
	}

	private static ListNode reverseLinkedList(ListNode head) {
		ListNode prev = null;
		ListNode curr = head;
		ListNode next = null;

		while (curr != null) {
			next = curr.next; // store next node
			curr.next = prev; // reverse current node's pointer
			prev = curr; // move pointers one pos ahead
			curr = next;
		}
		return prev; // new head of the LL

	}

	private static ListNode deleteMiddle(ListNode head) {

		if (head == null || head.next == null) {
			head = null;
		}

		ListNode slow = head;
		ListNode fast = head;
		ListNode prev = null;

		while (fast != null && fast.next != null) {
			fast = fast.next.next;
			prev = slow;
			slow = slow.next;
		}

		if (prev != null) {
			prev.next = slow.next;
		}

		return head;

	}

}
