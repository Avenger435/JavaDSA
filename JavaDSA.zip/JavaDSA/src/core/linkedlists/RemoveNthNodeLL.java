package core.linkedlists;

public class RemoveNthNodeLL {

	public static void main(String[] args) {

		// 1,2,3,4,5
		ListNode head = new ListNode(1, new ListNode(2, new ListNode(3, new ListNode(4, new ListNode(5)))));

		System.out.println(head);

		System.out.println(removeNthFromEnd(head, 2));

	}

	public static ListNode removeNthFromEnd(ListNode head, int n) {

		if (head == null)
			return head;

		ListNode dummy = new ListNode(-1);
		dummy.next = head;
		// to remove nth node , first find the nth node;
		ListNode x = findFromEnd(dummy, n + 1);
		x.next = x.next.next;

		return dummy.next;
	}

	// return the nth node.
	private static ListNode findFromEnd(ListNode head, int k) {

		// p1 moves k steps at first.
		ListNode p1 = head;
		for (int i = 0; i < k; i++) {
			p1 = p1.next;
		}

		// p1 & p2 move n-k steps together.
		ListNode p2 = head;
		while (p2 != null && p1 != null) {
			p2 = p2.next;
			p1 = p1.next;
		}

		// p2 is now pointing to the (n-k+1)-th node, which is the k-th node from the
		// end.
		return p2;
	}

}
