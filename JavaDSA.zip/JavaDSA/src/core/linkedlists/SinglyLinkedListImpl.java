package core.linkedlists;

import java.util.logging.Logger;

public class SinglyLinkedListImpl {

	public static void main(String[] args) {
		SinglyLinkedList list = new SinglyLinkedList();
		list.insertAtEnd(1);
		list.printLL();
		list.insertAtEnd(2);
		list.insertAtEnd(3);

		list.insertAtEnd(2);
		list.insertAtEnd(3);
		list.insertAtEnd(2);
		list.insertAtEnd(3);
		list.deleteAtPosition(0);
		list.insertAtEnd(4);
		list.insertAtBeginning(5);
		list.printLL();
		list.deleteByKey(4);
		list.printLL();
		list.insertAtBeginning(22);
		list.printLL();
		list.deleteAtPosition(7);
		list.printLL();
		list.search(22);
		list.search(3);
	}

}

class ListNode {
	int val;
	ListNode next;

	ListNode() {
	}

	ListNode(int val) {
		this.val = val;
		this.next = null;
	}

	ListNode(int val, ListNode next) {
		this.val = val;
		this.next = next;
	}

	@Override
	public String toString() {
		return "ListNode [val=" + val + ", next=" + next + "]";
	}

}

class SinglyLinkedList {

	public static final Logger logger = Logger.getAnonymousLogger();

	ListNode head;

	public SinglyLinkedList() {
		this.head = null;
	}

	public void insertAtBeginning(int val) {
		ListNode newNode = new ListNode(val);
		newNode.next = head;
		head = newNode;
	}

	public void insertAtEnd(int val) {
		ListNode newNode = new ListNode(val);
		if (head == null) {
			head = newNode;
		} else {
			ListNode curr = head;
			while (curr.next != null) {
				curr = curr.next;
			}
			curr.next = newNode;
		}

	}

	public void deleteAtPosition(int pos) {

		if (head == null)
			return;

		ListNode curr = head;
		if (pos == 0) {
			head = curr.next;
			return;
		}

		for (int i = 0; curr != null && i < pos - 1; i++) {
			curr = curr.next;
		}

		if (curr == null || curr.next == null) {
			System.out.println("Position : " + pos + " doesn't exist in LL");
			return;
		}

		ListNode next = curr.next.next;
		curr.next = next;

	}

	public boolean search(int key) {

		ListNode curr = head;
		int pos = 0;
		while (curr != null) {
			if (curr.val == key) {
				System.out.println("element found at position: " + pos);
				return true;
			}
			curr = curr.next;
			pos++;
		}

		return false;

	}

	public void deleteByKey(int key) {

		ListNode curr = head;
		ListNode prev = null;
		// check if head itself hold the key
		if (curr != null && curr.val == key) {
			head = curr.next;
			return;
		}
		// search for key to be deleted;
		while (curr != null && curr.val != key) {
			prev = curr;
			curr = curr.next;
		}
		if (curr == null) {
			logger.info("Key not found");
			return;
		}
		prev.next = curr.next;
	}

	public void printLL() {
		System.out.println();
		if (head == null) {
			System.out.println("List is currently empty");
			return;
		}
		ListNode curr = head;
		while (curr != null) {
			System.out.print(curr.val + " -> ");
			curr = curr.next;
		}
		System.out.print("null");
		System.out.println();
	}

}
