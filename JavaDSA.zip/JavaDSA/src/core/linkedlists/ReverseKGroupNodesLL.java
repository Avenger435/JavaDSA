package core.linkedlists;

public class ReverseKGroupNodesLL {

	public static void main(String[] args) {

		ListNode root = new ListNode(1);
		root.next = new ListNode(2);
		root.next.next = new ListNode(3);
		root.next.next.next = new ListNode(4);
		root.next.next.next.next = new ListNode(5);

		System.out.println(root);
		System.out.println("Result: " + reverseKGroup(root, 2));

	}

	public static ListNode reverseKGroup(ListNode head, int k) {
		if (head == null || k == 1) {
			return head;
		}

		ListNode dummy = new ListNode(0);
		dummy.next = head;
		ListNode pre = dummy;
		ListNode end = dummy;

		while (true) {
			int count = 0;
			while (end != null && count < k) {
				end = end.next;
				count++;
			}
			if (end == null)
				break;

			ListNode start = pre.next;
			ListNode next = end.next;
			end.next = null;
			pre.next = reverse(start);
			start.next = next;
			pre = start;
			end = pre;
		}
		return dummy.next;
	}

	private static ListNode reverse(ListNode curr) {
		ListNode prev = null;
		while (curr != null) {
			ListNode next = curr.next;
			curr.next = prev;
			prev = curr;
			curr = next;
		}
		return prev;
	}

	private static ListNode reverseKGrp(ListNode head, int k) {

		if (head == null || k == 1) {
			return head;
		}

		ListNode dummy = new ListNode(0);
		dummy.next = head;
		ListNode prev = dummy;
		ListNode end = dummy;

		while (true) {
			int count = 0;
			while (end != null && count < k) {
				end = end.next;
				count++;
			}
			if (end == null)
				break;

			ListNode start = prev.next;
			ListNode next = end.next;
			end.next = null;
			prev.next = reverse(start);
			start.next = next;
			prev = start;
			end = prev;
		}

		return head;

	}

}
