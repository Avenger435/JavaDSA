package core.linkedlists;

public class OddEvenNumberLL {

	public static void main(String[] args) {

		ListNode l1 = new ListNode(1);
		l1.next = new ListNode(2);
		l1.next.next = new ListNode(3);
		l1.next.next.next = new ListNode(4);
		l1.next.next.next.next = new ListNode(5);
		System.out.println(l1);
		System.out.println(oddEvenNumber(l1));
	}

	private static ListNode oddEvenNumber(ListNode head) {

		if (head == null) {
			return head;
		}

		ListNode odd = head;
		ListNode even = head.next;
		ListNode evenHead = even; // store even head to link later

		while (even != null && even.next != null) {
			odd.next = even.next;
			odd = odd.next;
			even.next = odd.next;
			even = even.next;
		}

		odd.next = evenHead;

		return head;
	}

}
