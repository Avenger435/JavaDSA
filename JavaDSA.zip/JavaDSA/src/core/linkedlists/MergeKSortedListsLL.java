package core.linkedlists;

import java.util.PriorityQueue;

public class MergeKSortedListsLL {

	public static void main(String[] args) {
		// 1,2,4
		ListNode headA = new ListNode(1, new ListNode(4, new ListNode(5, null)));

		// 1,3,4
		ListNode headB = new ListNode(1, new ListNode(3, new ListNode(4, null)));

		// 2,6
		ListNode headC = new ListNode(1, new ListNode(3, new ListNode(4, null)));

		ListNode[] lists = { headA, headB, headC };

		System.out.println(headA);
		System.out.println(headB);
		System.out.println("result: " + mergeKLists(lists));

	}

	public static ListNode mergeKLists(ListNode[] lists) {

		if (lists.length == 0)
			return null;
		// vnode
		ListNode dummy = new ListNode(-1);
		ListNode p = dummy;

		// Priority queue
		PriorityQueue<ListNode> pq = new PriorityQueue<>(lists.length, (a, b) -> (a.val - b.val));

		// add nodes to the min heap
		for (ListNode head : lists) {
			if (head != null)
				pq.add(head);
		}

		while (!pq.isEmpty()) {

			// get the smallest node and attach it to the result linked list.
			ListNode node = pq.poll();
			p.next = node;
			if (node.next != null) {
				pq.add(node.next);
			}
			// move p forward
			p = p.next;
		}
		return dummy.next;

	}

}
