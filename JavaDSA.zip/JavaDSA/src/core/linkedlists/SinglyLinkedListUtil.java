package core.linkedlists;

public class SinglyLinkedListUtil {

	public static void main(String[] args) {

		System.out.println("here");

		int[] arr = { 1, 2, 3, 4, 5 };

		ListNode result = creatLinkedList(arr);

		System.out.println(result);
		traverseLL(result);
		System.out.println();
		ListNode insertAtHead = insertAtHead(result, 10);
		System.out.println("insertAtHead" + insertAtHead);
		System.out.println();
		ListNode insertAtTail = insertAtTail(result, 11);
		System.out.println("insertAtTail: " + insertAtTail);
		System.out.println();
		ListNode insertAtTail2 = insertAtTail(null, 11);
		System.out.println("insertAtTail2: " + insertAtTail2);
		System.out.println();
		ListNode insertAtPos = insertAtPos(result, 21, 4);
		System.out.println("insertAtPos: " + insertAtPos);
		System.out.println();
		ListNode deleteAtPos = deleteAtPos(insertAtPos, 4);
		System.out.println("deleteAtPos: " + deleteAtPos);
		System.out.println();
		ListNode deleteAtTail = deleteAtTail(deleteAtPos);
		System.out.println("deleteAtTail" + deleteAtTail);
		System.out.println();
		ListNode deleteAtHead = deleteAtHead(deleteAtTail);
		System.out.println(deleteAtHead);
		System.out.println();
	}

	public static ListNode creatLinkedList(int[] arr) {

		if (arr == null || arr.length == 0) {
			return null;
		}

		ListNode dummy = new ListNode(arr[0]);
		ListNode curr = dummy;

		for (int i = 1; i < arr.length; i++) {
			curr.next = new ListNode(arr[i]);
			curr = curr.next;
		}

		return dummy;
	}

	private static void traverseLL(ListNode head) {

		for (ListNode p = head; p != null; p = p.next) {
			System.out.print(p.val + "->");
		}
		System.out.print("null");
		System.out.println();
	}

	private static ListNode insertAtHead(ListNode head, int val) {

		ListNode newNode = new ListNode(val);
		if (head == null) {
			return newNode;
		}

		newNode.next = head;
		head = newNode;
		return head;
	}

	private static ListNode insertAtTail(ListNode head, int val) {
		// create a new node
		ListNode newNode = new ListNode(val);
		if (head == null) {
			return newNode;
		}
		ListNode curr = head;
		// go to the last node of the list.
		while (curr.next != null) {
			curr = curr.next;
		}
		curr.next = newNode;
		return head;
	}

	private static ListNode insertAtPos(ListNode head, int val, int pos) {

		ListNode newNode = new ListNode(val);
		if (head == null)
			return newNode;

		ListNode p = head;
		for (int i = 0; i < pos; i++) {
			p = p.next;
		}
		newNode.next = p.next;
		p.next = newNode;
		return head;

	}

	private static ListNode deleteAtPos(ListNode head, int pos) {

		if (head == null)
			return null;

		ListNode p = head;
		for (int i = 0; i < pos; i++) {
			p = p.next;
		}
		p.next = p.next.next;
		return head;

	}

	private static ListNode deleteAtTail(ListNode head) {

		if (head == null)
			return null;

		ListNode curr = head;
		while (curr.next.next != null) {
			curr = curr.next;
		}
		curr.next = null;
		return head;
	}

	private static ListNode deleteAtHead(ListNode head) {

		if (head == null)
			return null;
		head = head.next;
		return head;
	}

}
