package core.linkedlists;

public class PairSumLL {

	public static void main(String[] args) {

		ListNode l1 = new ListNode(5);
		l1.next = new ListNode(4);
		l1.next.next = new ListNode(3);
		l1.next.next.next = new ListNode(2);
		l1.next.next.next.next = new ListNode(1);
		System.out.println(l1);
		System.out.println(twinPairSum(l1));

	}

	private static int twinPairSum(ListNode head) {

		int maxPairSum = 0;

		if (head == null) {
			return 0;
		}

		// find the mid of the ll

		ListNode fast = head;
		ListNode slow = head;
		ListNode prev = null;

		while (fast != null && fast.next != null) {
			fast = fast.next.next;
			ListNode temp = slow.next;
			slow.next = prev;
			prev = slow;
			slow = temp;
		}

		// Calculate max;

		ListNode reverse = prev;
		while (slow != null && reverse != null) {
			maxPairSum = Math.max(maxPairSum, slow.val + reverse.val);
			slow = slow.next;
			reverse = reverse.next;
		}

		return maxPairSum;
	}

}
