package core.linkedlists;

public class RemoveElementByValLL {

	public static void main(String[] args) {

//		1,2,6,3,4,5,6
		ListNode creatLinkedList = SinglyLinkedListUtil.creatLinkedList(new int[] { 1, 2, 6, 3, 4, 5, 6 });

		ListNode creatLinkedList1 = SinglyLinkedListUtil.creatLinkedList(new int[] { 7, 7, 7, 7 });

		System.out.println("creatLinkedList: " + creatLinkedList1);
		System.out.println("removeElements: " + removeElements(creatLinkedList1, 7));

	}

	public static ListNode removeElements(ListNode head, int val) {

		ListNode dummy = new ListNode(-1);
		dummy.next = head;
		ListNode curr = dummy;

		while (curr.next != null) {
			if (curr.next.val == val) {
				curr.next = curr.next.next;
			} else {
				curr = curr.next;
			}
		}

		return dummy.next;
	}

}
