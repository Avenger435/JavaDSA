package core.linkedlists;

import java.util.Arrays;

public class MinPairRemovalLL {

	public static void main(String[] args) {

		minimumPairRemoval(new int[] { 5, 2, 3, 1 });

	}

	public static int minimumPairRemoval(int[] nums) {
		int operations = 0;
		int len = nums.length - 1;
		int leastSum = Integer.MAX_VALUE;
		while (len != 0) {
			for (int slow = 0, fast = 1; slow < len; slow++, fast++) {
				int sum = nums[slow] + nums[fast];
				if (sum < leastSum) {
					leastSum = sum;
					nums[slow] = leastSum;
				}
			}

			--len;
		}
		System.out.println(Arrays.toString(nums));

		return 0;
	}

}
