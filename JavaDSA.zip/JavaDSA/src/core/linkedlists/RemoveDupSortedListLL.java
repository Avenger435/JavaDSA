package core.linkedlists;

public class RemoveDupSortedListLL {

	public static void main(String[] args) {

		ListNode creatLinkedList = SinglyLinkedListUtil.creatLinkedList(new int[] { 1, 1, 1 });

		System.out.println(creatLinkedList);

		ListNode deleteDuplicates = deleteDuplicates(creatLinkedList);
		System.out.println("deleteDuplicates : " + deleteDuplicates);
	}

	public static ListNode deleteDuplicates(ListNode head) {

		if (head == null)
			return head;

		ListNode fast = head.next;
		ListNode slow = head;

		while (fast != null) {
			if (fast.val != slow.val) {
				slow.next = fast;
				slow = slow.next;
			}
			fast = fast.next;
		}

		slow.next = null;
		return head;

	}
}
