package com.leet.review;

import java.util.Arrays;
import java.util.TreeMap;
import java.util.TreeSet;

public class MaxProfit {

	public static void main(String[] args) {

		int[] prices = new int[] { 7, 1, 5, 3, 6, 4 };
		MaxProfit maxProf = new MaxProfit();
		maxProf.maxProfit(prices);
	}

	public int maxProfit(int[] prices) {

		maxProfit(prices, new TreeSet<>());
		Arrays.toString(prices);
		return 0;

	}

	public int maxProfit(int[] prices, TreeSet<Integer> treeset) {

		for (int i = 0; i < prices.length; i++) {
			treeset.add(prices[i]);
		}
		System.out.println("minVAL: " + treeset.getFirst() + " minVal: " + treeset.getLast());
		System.out.println("hashMap: " + treeset);
		return 0;
	}

}
