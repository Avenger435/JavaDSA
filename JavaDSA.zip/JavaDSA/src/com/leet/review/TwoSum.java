package com.leet.review;

import java.util.Arrays;
import java.util.HashMap;

public class TwoSum {

	public static void main(String[] args) {

		TwoSum two = new TwoSum();
//		System.out.println("==> " + Arrays.toString(two.twoSum(new int[] { 3, 2, 3 }, 6)));
		System.out.println("==> " + Arrays.toString(two.sample(new int[] { 2, 7, 11, 15 }, 9)));

//		System.out.println("==> " + Arrays.toString(two.twoSum(new int[] { 0, 2, 5 }, 7)));

	}

	public int[] twoSum(int[] nums, int target) {

		int[] result = new int[2];
		for (int i = 0; i < nums.length; ++i) {
			for (int j = nums.length - 1; j >= 0; --j) {
				if (nums[i] + nums[j] == target) {
					result[0] = i;
					result[1] = j;
				}
			}
		}

		return result;

	}

	public int[] sample(int[] nums, int target) {

		HashMap<Integer, Integer> hashMap = new HashMap<>();
		int[] result = new int[2];
		for (int i = 0; i < nums.length; i++) {
			if (hashMap.containsKey(target - nums[i])) {
				result[0] = hashMap.get(target - nums[i]);
				result[1] = i;
			}
			hashMap.put(nums[i], i);
		}
		return result;
	}

}
