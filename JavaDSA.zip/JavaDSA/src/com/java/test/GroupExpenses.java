package com.java.test;

import java.util.HashMap;
import java.util.Map;

public class GroupExpenses {
	private Map<String, Double> expenses;
	private Map<String, Double> balances;

	public GroupExpenses() {
		expenses = new HashMap<>();
		balances = new HashMap<>();
	}

	public void addExpense(String person, double amount) {
		expenses.put(person, expenses.getOrDefault(person, 0.0) + amount);
	}

	public void calculateBalances() {
		double totalExpense = expenses.values().stream().mapToDouble(Double::doubleValue).sum();
		double perPersonExpense = totalExpense / expenses.size();

		for (String person : expenses.keySet()) {
			balances.put(person, expenses.get(person) - perPersonExpense);
		}
	}

	public void printBalances() {
		System.out.println("Balances:");
		for (Map.Entry<String, Double> entry : balances.entrySet()) {
			System.out.println(entry.getKey() + ": " + entry.getValue());
		}
	}

	public static void main(String[] args) {
		GroupExpenses groupExpenses = new GroupExpenses();

		// Adding expenses
		groupExpenses.addExpense("Mani", 32949.0);
		groupExpenses.addExpense("Gullu", 6918.0);
		groupExpenses.addExpense("Sourav", 1050.0);

		// Calculating balances
		groupExpenses.calculateBalances();

		// Printing balances
		groupExpenses.printBalances();
	}
}
