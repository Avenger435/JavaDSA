package com.java.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListExample {
	public static void main(String[] args) {
		List<String> arrList = new ArrayList<>();
		arrList.add("Element 1");
		arrList.add("Element 2");
		arrList.add("Element 3");

		CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<>(arrList);

		// Adding elements

		System.out.println("ArrayList " + arrList);
		// Iterating over the list
		System.out.println("CopyOnWriteArrayList " + list);

		// Removing an element
		list.remove("Element 2");

		System.out.println("ArrayList " + arrList);
		System.out.println("CopyOnWriteArrayList " + list);

	}
}
