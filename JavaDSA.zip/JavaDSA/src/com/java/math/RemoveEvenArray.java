package com.java.math;

import java.util.Arrays;

public class RemoveEvenArray {

	public static void main(String[] args) {

		RemoveEvenArray array = new RemoveEvenArray();
		int[] arr = new int[] { 2, 3, 4, 5, 6, 7, 8, 9 };
//		int[] removeEven = array.removeEven(arr);
		int[] removeEven2 = array.removeEven2(arr);
		System.out.println(Arrays.toString(removeEven2));
	}

	// remove even array
	public int[] removeEven(int[] arr) {

		int counter = 0;

		// find the even index

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % 2 != 0) {
				counter++;
			}
		}

		int[] result = new int[counter];
		int idx = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % 2 != 0) {
				result[idx] = arr[i];
				idx++;
			}
		}

		return result;
	}

	//
	public int[] removeEven2(int[] arr) {

		int[] result = new int[2];
		System.out.println("==> " + Arrays.toString(arr));

		int start = 0;
		int end = arr.length - 1;
		int idx=0;
		for (int i = 0; i < arr.length-1; i++) {
			if (arr[i] % 2 == 0) {
				int temp = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = temp;
				
			} else {
				continue;
			}
		}
		System.out.println("==> " + Arrays.toString(arr));
		return result;
	}

}
