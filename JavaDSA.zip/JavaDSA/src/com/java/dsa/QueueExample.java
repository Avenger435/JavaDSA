package com.java.dsa;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Queue example.
 * 
 * LIFO
 * 
 * add = enqueue, offer() remove = dequeue, poll()
 * 
 * Example theater queue.
 * 
 */

public class QueueExample {

	public static void main(String[] args) {

		Queue<String> queue = new LinkedList<>();

		System.out.println(queue.isEmpty());
		// adding
		queue.offer("first");
		queue.offer("second");
		queue.offer("third");
		queue.offer("fourth");
		queue.offer("fourth");
		// methods from collection class
		System.out.println(queue.isEmpty());
		// size
		System.out.println(queue.size());
		// contains
		System.out.println(queue.contains("third"));

		System.out.println(queue);

		System.out.println(queue.peek());
		queue.poll();
		queue.poll();
		queue.poll();
		queue.poll();

		// peeks the top element
		System.out.println(queue.peek());
		queue.poll();
		// returns empty queue and doesn't throw exception
		queue.poll();
		// throws an exception
//		queue.element();
		System.out.println(queue);

		// queue usage
		// 1. keyboard buffer
		// 2. printer queue
		// 3. used in LinkedList, PriorityQueue, BFS

	}

}
