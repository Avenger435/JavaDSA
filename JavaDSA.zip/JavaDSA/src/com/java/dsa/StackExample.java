package com.java.dsa;

import java.util.Stack;

/**
 * stack operations.
 * 
 * LIFO DS. tower of objects
 * 
 */
public class StackExample {

	public static void main(String[] args) {

		Stack<String> stack = new Stack<>();

		System.out.println(stack.isEmpty());
		// adds elements into stack
		stack.push("Minecraft");
		stack.push("RDR");
		stack.push("RDR2");
		stack.push("Origins");
		stack.push("Medival dynasty");
		System.out.println(stack.isEmpty());
		// peeks the top most element
		System.out.println(stack.peek());
		String myfavgame = stack.pop();
		System.out.println(myfavgame);
		// removes the top most element
		System.out.println(stack.pop());
		// -1 when no matching found
		System.out.println(stack.search("Rdr"));

		// uses of stacks
		// 1. undo/redo features in text editors
		// 2. moving back/forward in browser history
		// 3. backtracking algo (maze, file directories)
		// 4. calling functions (call stacks)

	}

}
