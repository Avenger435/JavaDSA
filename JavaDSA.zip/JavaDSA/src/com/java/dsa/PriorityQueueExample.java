package com.java.dsa;

import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueExample {

	public static void main(String[] args) {

		Queue<Integer> queue = new PriorityQueue<Integer>(Collections.reverseOrder());

		System.out.println(queue.isEmpty());
		// adding
		queue.offer(1);
		queue.offer(10);
		queue.offer(20);
		queue.offer(60);
		queue.offer(-1);
		// methods from collection class
		System.out.println(queue.isEmpty());
		// size
		System.out.println(queue.size());
		// contains
		System.out.println(queue.contains(22));

		System.out.println(queue);

		System.out.println(queue.peek());
		queue.poll();
		queue.poll();
		queue.poll();
		queue.poll();

		// peeks the top element
		System.out.println(queue.peek());
		queue.poll();
		// returns empty queue and doesn't throw exception
		queue.poll();
		// throws an exception
		// queue.element();
		System.out.println(queue);

		// queue usage
		// 1. keyboard buffer
		// 2. printer queue
		// 3. used in LinkedList, PriorityQueue, BFS

	}

}
