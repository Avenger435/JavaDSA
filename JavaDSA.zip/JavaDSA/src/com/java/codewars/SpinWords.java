package com.java.codewars;

import java.util.Arrays;
import java.util.stream.Collectors;

public class SpinWords {

	public static void main(String[] args) {

		System.out.println(spinWords("Hey fellow warriors"));

	}

	public static String spinWords(String sentence) {

		return Arrays.stream(sentence.split("\s"))
				.map(str -> str.length() >= 5 ? new StringBuilder(str).reverse().toString() : str)
				.collect(Collectors.joining("\s"));

	}

}
