package com.java.codewars;

public class FacebookLikes {

	public static void main(String[] args) {
		System.out.println("==================================================");
		System.out.println(whoLikesIt());
		System.out.println(whoLikesIt("Peter"));
		System.out.println(whoLikesIt("Peter", "Quagmire"));
		System.out.println(whoLikesIt("Peter", "Quagmire", "Joe"));
		System.out.println(whoLikesIt("Peter", "Quagmire", "Joe", "Cleveland"));

		System.out.println("==================================================");
		System.out.println("Impl 2 ");
		System.out.println(whoLikesIt1());
		System.out.println(whoLikesIt1("Peter"));
		System.out.println(whoLikesIt1("Peter", "Quagmire"));
		System.out.println(whoLikesIt1("Peter", "Quagmire", "Joe"));
		System.out.println(whoLikesIt1("Peter", "Quagmire", "Joe", "Cleveland"));

	}

	public static String whoLikesIt1(String... names) {

		final String Template0 = "No one likes this";
		final String Template1 = "%s likes this";
		final String Template2 = "%s, %s like this";
		final String Template3 = "%s, %s and %s like this";
		final String Template4 = "%s, %s and %d others like this";

		switch (names.length) {
		case 0:
			return String.format(Template0);
		case 1:
			return String.format(Template1, names[0]);
		case 2:
			return String.format(Template2, names[0], names[1]);
		case 3:
			return String.format(Template3, names[0], names[1], names[2]);
		default:
			return String.format(Template4, names[0], names[1], names.length - 2);
		}

	}

	public static String whoLikesIt(String... names) {
		final String AND = " and ";
		final String LIKES_THIS = " likes this";
		int length = names.length;

		StringBuilder sb = new StringBuilder();

		switch (length) {
		case 0:
			sb.append("No one likes this");
			break;
		case 1:
			sb.append(names[0]).append(LIKES_THIS);
			break;
		case 2:
			sb.append(names[0]).append(AND).append(names[1]).append(LIKES_THIS);
			break;
		case 3:
			sb.append(names[0]).append(", ").append(names[1]).append(AND).append(names[2]).append(LIKES_THIS);
			break;
		default:
			sb.append(names[0]).append(", ").append(names[1]).append(AND).append((length - 2)).append(" others ")
					.append(LIKES_THIS);
			break;
		}

		return sb.toString();
	}
}
