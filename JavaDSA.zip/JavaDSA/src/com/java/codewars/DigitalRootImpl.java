package com.java.codewars;

import java.util.stream.Stream;

public class DigitalRootImpl {

	public static void main(String[] args) {
		System.out.println(digital_root5(16));
		System.out.println(digital_root5(942));
		System.out.println(digital_root5(132189));
		System.out.println(digital_root5(493193));

	}

	public static int digital_root5(int n) {

		if (n < 10) {
			return getSum(n);
		} else {
			return digital_root(getSum(n));
		}

	}

	private static int getSum(int n) {
		return Stream.of(String.valueOf(n).split("")).mapToInt(Integer::parseInt).sum();
	}

	public static int digital_root4(int n) {
		return n < 10 ? n : digital_root(digital_root(n / 10 + n % 10));
	}

	public static int digital_root3(int n) {
		return (1 + (n - 1) % 9);
	}

	public static int digital_root2(int n) {
		while (n > 9) {
			n = n / 10 + n % 10;
		}
		return n;
	}

	public static int digital_root(int n) {

		int sum = 0;
		for (String s : String.valueOf(n).split(""))
			sum += Integer.parseInt(s);
		if (sum <= 9)
			return sum;
		else
			return digital_root(sum);
	}

}
