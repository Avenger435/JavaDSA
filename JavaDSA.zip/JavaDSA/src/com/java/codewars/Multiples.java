package com.java.codewars;

public class Multiples {

	public static void main(String[] args) {

		System.out.println(solution(20));

	}

	private static int solution(int n) {

		int sum = 0;
		for (int i = 0; i < n; i++) {
			if (i % 3 == 0) {
				sum += i;
			}
			if (i % 5 == 0) {
				sum += i;
			}
			if (i % 5 == 0 && i % 3 == 0) {
				sum -= i;
			}

		}
		return sum;
	}

}
