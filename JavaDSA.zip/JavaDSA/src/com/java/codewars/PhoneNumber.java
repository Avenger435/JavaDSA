package com.java.codewars;

public class PhoneNumber {

	public static void main(String[] args) {

		int[] numbers = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };

		System.out.println(createPhoneNumber(numbers));

	}

	private static String createPhoneNumber(int[] numbers) {
		return String.format("(%d%d%d) %d%d%d-%d%d%d%d", java.util.stream.IntStream.of(numbers).boxed().toArray());
	}

}
