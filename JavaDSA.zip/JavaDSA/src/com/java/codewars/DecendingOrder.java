package com.java.codewars;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DecendingOrder {

	public static void main(String[] args) {

		System.out.println(sortDesc(12442));
		System.out.println(sortDesc1(12442));
		System.out.println(sortDesc2(12442));
		System.out.println(sortDesc3(12442));

	}

	private static int sortDesc3(int num) {

		return Integer.parseInt(Stream.of(String.valueOf(num).split("")).sorted(Comparator.reverseOrder())
				.collect(Collectors.joining()));

	}

	private static int sortDesc2(int num) {

		return Integer.parseInt(Integer.toString(num).codePoints().sorted()
				.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).reverse()
				.toString());
	}

	private static int sortDesc1(int num) {

		String[] arr = String.valueOf(num).split("");
		Arrays.sort(arr, Collections.reverseOrder());
		return Integer.valueOf(String.join("", arr));
	}

	public static int sortDesc(int num) {
		int[] intArr = String.valueOf(num).chars().map(Character::getNumericValue).boxed().sorted((a, b) -> b - a)
				.mapToInt(Integer::intValue).toArray();
		StringBuilder sb = new StringBuilder();
		for (int i : intArr)
			sb.append(i);
		return Integer.valueOf(sb.toString());
	}

}
