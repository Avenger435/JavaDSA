package com.java.codewars;

import java.util.Arrays;
import java.util.Random;

public class MaxSumSubsequence {

	public static void main(String[] args) {
		Random random = new Random();

		System.out.println(sequence(new int[] { -2, 1, -3, 4, -1, 2, 1, -5, 4 }));

		System.out.println(sequence(new int[] { -16, 28, 10, 23, 28, -28, 13, 14, 0, 22, 12, -14, -29, -1, 0, 5, -1,
				-13, 25, -14, 9, 5, 19, -19, -6, -7, 0, -4, 26, -29, -17, 21, 12, 9, 22, -15, -10, -17, 16, 4, 19, 22,
				1, 8, 13, 18, 9, 24, -1, 11, 19, 22, 13, -23, 21 }));

		System.out.println(sequence(new int[] { 7, 4, 11, -11, 39, 36, 10, -6, 37, -10, -32, 44, -26, -34, 43, 43 }));

	}

	public static int sequence(int[] arr) {

		System.out.println("Input Array");
		System.out.println(Arrays.toString(arr));

		Integer max = Integer.MIN_VALUE;
		int left = 0;
		int right = 1;

		int sum = 0;
		while (right < arr.length) {
			sum = Arrays.stream(arr, left, right).sum();
			// if sum is > max then increment right;
			if (sum > max) {
				max = sum;
				right++;
			} else if (sum < max) {
				right++;
			} else {
				right++;
				left++;
			}

			System.out.println("max " + max + " sum " + sum + " left " + left + " right " + right);
		}

		return max < 0 ? 0 : max;
	}

	private static int[] getRandomArray(int size, Random random) {

		int[] randomArray = new int[size];

		for (int i = 0; i < size; i++) {
			randomArray[i] = random.nextInt(100); // Generates a random integer between 0 and 99
		}

		return randomArray;
	}

}
