package trees.binary;

public class MaxDepthBT {

	public static void main(String[] args) {

		BinaryTree tree = new BinaryTree();
		tree.root = new TreeNode(3);
		tree.root.left = new TreeNode(9);
		tree.root.right = new TreeNode(20);
		tree.root.right.right = new TreeNode(15);
		tree.root.right.left = new TreeNode(7);

		System.out.println("Tree: " + tree);

		System.out.println("max Depth: " + maxDepth(tree.root));
	}

	private static int maxDepth(TreeNode root) {

		if (root == null) {
			return 0;
		}

		int leftDepth = maxDepth(root.left);
		int rightDepth = maxDepth(root.right);

		return Math.max(rightDepth, leftDepth) + 1;
	}

}
