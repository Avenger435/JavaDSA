package trees.binary;

public class MinDepthBT {
	public static void main(String[] args) {

		BinaryTree tree = new BinaryTree();
		tree.root = new TreeNode(3);
		tree.root.left = new TreeNode(9);
		tree.root.right = new TreeNode(20);
		tree.root.right.right = new TreeNode(15);
		tree.root.right.left = new TreeNode(7);

		System.out.println("Tree: " + tree);

		System.out.println("max Depth: " + minDepth(tree.root));

	}

	private static int minDepth(TreeNode node) {

		if (node == null)
			return 0;

		if (node.left == null)
			return minDepth(node.right) + 1;

		if (node.right == null)
			return minDepth(node.left) + 1;

		return Math.min(minDepth(node.left), minDepth(node.right)) + 1;
	}
}
