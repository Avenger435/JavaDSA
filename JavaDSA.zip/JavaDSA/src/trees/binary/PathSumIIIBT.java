package trees.binary;

import java.util.HashMap;
import java.util.Map;

/**
 * Definition for a binary tree node. public class TreeNode { int val; TreeNode
 * left; TreeNode right; TreeNode() {} TreeNode(int val) { this.val = val; }
 * TreeNode(int val, TreeNode left, TreeNode right) { this.val = val; this.left
 * = left; this.right = right; } }
 */
class Solution {
	public int pathSum(TreeNode root, int targetSum) {

		Map<Long, Long> prefixSumCount = new HashMap<>();
		prefixSumCount.put(Long.valueOf(0), Long.valueOf(1)); // base case one way to get sum - if node val is 0;

		return dfs(root, Long.valueOf(0), Long.valueOf(targetSum), prefixSumCount);

	}

	private static int dfs(TreeNode node, Long currSum, Long targetSum, Map<Long, Long> prefixSumCount) {

		if (node == null) {
			return 0;
		}

		currSum += node.val;

		Long ans = prefixSumCount.getOrDefault(currSum - targetSum, Long.valueOf(0));
		prefixSumCount.merge(currSum, Long.valueOf(1), Long::sum);

		ans += dfs(node.left, currSum, targetSum, prefixSumCount);
		ans += dfs(node.right, currSum, targetSum, prefixSumCount);

		prefixSumCount.merge(currSum, Long.valueOf(-1), Long::sum); // remove the current node's sum from the map

		return ans.intValue();

	}

}