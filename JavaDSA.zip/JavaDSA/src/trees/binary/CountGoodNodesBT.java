package trees.binary;

public class CountGoodNodesBT {

	public static void main(String[] args) {

		TreeNode root = new TreeNode(3);
		root.left = new TreeNode(1);
		root.right = new TreeNode(4);
		root.left.left = new TreeNode(3);
		root.right.left = new TreeNode(1);
		root.right.right = new TreeNode(5);

		System.out.println(root);

		System.out.println(goodNodes(root));

	}

	public static int goodNodes(TreeNode root) {

		return dfs(root, Integer.MIN_VALUE);

	}

	private static int dfs(TreeNode node, int maxSoFar) {

		if (node == null) {
			return 0;
		}

		int good = 0;
		if (node.val >= maxSoFar) {
			good = 1;
			maxSoFar = node.val;
		}

		return good + dfs(node.left, maxSoFar) + dfs(node.right, maxSoFar);

	}

}
