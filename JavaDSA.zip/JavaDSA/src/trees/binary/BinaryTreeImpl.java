package trees.binary;

import java.util.LinkedList;
import java.util.Queue;

public class BinaryTreeImpl {

	public static void main(String[] args) {

		BinaryTree tree = new BinaryTree();
		System.out.println(tree);

		tree.root = new TreeNode(1);
		tree.root.left = new TreeNode(2);
		tree.root.right = new TreeNode(3);
		tree.root.left.left = new TreeNode(4);
		tree.root.left.right = new TreeNode(5);

		System.out.println("tree: " + tree);

		System.err.println("Inoderer traversal");
		tree.inorderTraversal();

		System.out.println();
		System.err.println("preorder traversal");
		tree.preorderTraversal();

		System.out.println();
		System.err.println("post traversal");
		tree.postorderTraversal();

	}

}

class TreeNode {

	int val;
	TreeNode left;
	TreeNode right;

	public TreeNode(int item) {
		val = item;
		left = right = null;
	}

	public TreeNode(int item, TreeNode left, TreeNode right) {
		val = item;
		this.right = right;
		this.left = left;

	}

	@Override
	public String toString() {
		return "TreeNode [data=" + val + ", left=" + left + ", right=" + right + "]";
	}

}

class BinaryTree {
	TreeNode root;

	BinaryTree() {
		root = null;
	}

	@Override
	public String toString() {
		return "BinaryTree [root=" + root + "]";
	}

	void preorder(TreeNode node) {
		if (node == null) {
			return;
		}

		System.out.print(node.val + " ");
		preorder(node.left);
		preorder(node.right);
	}

	void inOrder(TreeNode node) {
		if (node == null) {
			return;
		}

		inOrder(node.left);
		System.out.print(node.val + " ");
		inOrder(node.right);

	}

	void postorder(TreeNode node) {
		if (node == null)
			return;

		postorder(node.left);
		postorder(node.right);
		System.out.print(node.val + " ");
	}

	void inorderTraversal() {
		inOrder(root);
	}

	void preorderTraversal() {
		preorder(root);
	}

	void postorderTraversal() {
		postorder(root);
	}

	// Method to print the binary tree in a structured format
	void printTree(TreeNode root) {
		if (root == null) {
			return;
		}

		Queue<TreeNode> queue = new LinkedList<>();
		queue.add(root);

		while (!queue.isEmpty()) {
			int levelSize = queue.size();

			while (levelSize > 0) {
				TreeNode node = queue.poll();
				System.out.print(node.val + " ");

				if (node.left != null) {
					queue.add(node.left);
				}
				if (node.right != null) {
					queue.add(node.right);
				}

				levelSize--;
			}
			System.out.println();
		}
	}

}