package trees.binary;

import java.util.ArrayList;
import java.util.List;

public class SimilarLeafNodesBT {

	public static void main(String[] args) {

//		[3,5,1,6,2,9,8,null,null,7,4]

		TreeNode root1 = new TreeNode(3, new TreeNode(5, new TreeNode(6), new TreeNode(2)),
				new TreeNode(1, new TreeNode(9), new TreeNode(8, new TreeNode(7), new TreeNode(4))));

		TreeNode root2 = new TreeNode(3, new TreeNode(5, new TreeNode(6), new TreeNode(2)),
				new TreeNode(1, new TreeNode(9), new TreeNode(8, new TreeNode(7), new TreeNode(4))));

		BinaryTree bt = new BinaryTree();
		bt.printTree(root1);

		System.out.println("are similar : " + similarLeaf(root1, root2));

	}

	private static boolean similarLeaf(TreeNode root1, TreeNode root2) {
		return getLeafNodes(root1).equals(getLeafNodes(root2));
	}

	private static void findLeafNodes(TreeNode node, List<Integer> leafNodesList) {
		if (node == null) {
			return;
		}
		if (node.left == null && node.right == null) {
			leafNodesList.add(node.val);
		}

		findLeafNodes(node.left, leafNodesList);
		findLeafNodes(node.right, leafNodesList);
	}

	private static List<Integer> getLeafNodes(TreeNode node) {
		List<Integer> leafNodes = new ArrayList<>();
		findLeafNodes(node, leafNodes);
		return leafNodes;
	}

}
