package searching;

import java.util.PriorityQueue;

public class MinTime2D {

	public static void main(String[] args) {

		int[][] moveTime = { { 0, 4 }, { 4, 4 } };

		System.out.println(minTimeToReach(moveTime));

	}

	public static int minTimeToReach(int[][] moveTime) {

		// initalizing variables
		int n = moveTime.length;
		int m = moveTime[0].length;

		// directions for the move.
		int[][] directions = { { 0, 1 }, { 1, 0 }, { 0, -1 }, { -1, 0 } };

		// PQ is initialized with [0,0] with time 0
		PriorityQueue<int[]> pq = new PriorityQueue<>((a, b) -> a[0] - b[0]);
		pq.offer(new int[] { 0, 0, 0 });
//		System.out.println("priority queue: " + pq);
		// min time to reach the given position.
		int[][] minTime = new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				minTime[i][j] = Integer.MAX_VALUE;
			}
		}

//		print2DArray(minTime);

		minTime[0][0] = 0;
		while (!pq.isEmpty()) {
			int[] current = pq.poll();
			int time = current[0];
			int x = current[1];
			int y = current[2];

			if (x == n - 1 && y == m - 1) {
				return time;
			}

			for (int[] direction : directions) {
				int nx = x + direction[0];
				int ny = y + direction[1];

				if (nx >= 0 && nx < n && ny >= 0 && ny < n) {

					int waitTime = Math.max(moveTime[nx][ny] - time, 0);
					int newTime = time + 1 + waitTime;
					if (newTime < minTime[nx][ny]) {
						minTime[nx][ny] = newTime;
						pq.offer(new int[] { newTime, nx, ny });
					}
				}

			}

		}

		return -1;

	}

	public static void print2DArray(int[][] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				System.out.print(array[i][j] + " ");
			}
			System.out.println();
		}
	}

}
